import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styles: []
})
export class CommentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
