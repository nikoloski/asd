import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class GeneralService {
	
	

  constructor(private http:Http) { }
  
  url:string = "https://jsonplaceholder.typicode.com/";

  getUsers()
  {
	  return this.http.get(this.url+'users')
	  .map((res:Response) => res.json())
	  .catch((err:Response) => { 
		return Observable.throw(err);
	  });
  }
  
  getUserById(id:number)
  {
		return this.http.get(this.url+'users/'+id).map((res:Response) => res.json()).catch((err:Response) => { return Observable.throw(err);});
  }
  
  getPosts()
  {
	  return this.http.get(this.url+'posts').map((res:Response) => res.json()).catch((err:Response) => { return Observable.throw(err);});
  }
  
  getPostById(id:number)
  {
	  return this.http.get(this.url+'posts/'+id).map((res:Response) => res.json()).catch((err:Response) => { return Observable.throw(err);});
  }
  
  getPostComments(id:number)
  {
	  return this.http.get(this.url+'posts/'+id+'/comments').map((res:Response) => res.json()).catch((err:Response) => { return Observable.throw(err);});
  }
}
