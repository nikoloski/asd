/*import { Component, Output, EventEmitter } from '@angular/core';*/
import { Component } from '@angular/core';

@Component({
  selector: 'app-subcomponent',
  templateUrl: './subcomponent.component.html',
  styleUrls: ['./subcomponent.component.css']
})
export class SubcomponentComponent {

  /*constructor() { }

  @Output() notifyParent:eventEmitter<any> = new EventEmitter();
  
  num:number = 0;
  
  emitEvent():void
  {
	  this.notifyParent.emit('I had notified the parent component');
	  this.num = this.num + 1;
  }
  
  returnNumber():number
  {
	  return this.num;
  }*/

}
