/*import { Component, ViewEncapsulation, Input, ViewChild } from '@angular/core';*/
import { Component, ViewEncapsulation } from '@angular/core';
/*import { SubcomponentComponent } from './subcomponent/subcomponent.component';*/
import { GeneralService } from './general.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  title = 'app works!';
  
  users:any;
  errors:any;
  constructor(private generalService:GeneralService){}
  
  loadUsers()
  {
	  this.generalService.getUsers().subscribe(data => this.users = data, error => this.errors = error);
  }

  /*@Input() textvar:string = 'This is default value';
   
  @ViewChild(SubcomponentComponent) subView:SubcomponentComponent; 
  constructor(){}
  
  newnumber:number = 0;
  
  childHadTriggered(event)
  {
	  console.log('Child component had triggered an event', event);
	  this.textvar = event;
  }
  
  getNumber():void
  {
	  this.newnumber = this.newnumber + this.subView.returnNumber();
  }*/
    
}
