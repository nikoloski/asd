import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  title = 'app';
  showtitle = true;
  
  counter:number = 0;
  
  items = [1, 2, 3, 4, 5, 6];
  
  constructor(){}
  
  incrementCounter()
  {
	  this.counter++;
  }
  
  decrementCounter()
  {
	  this.counter--;
  }
  
  
}
